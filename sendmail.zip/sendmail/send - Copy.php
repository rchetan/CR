<?php


$to = "rchetan4141@gmail.com";
$subject = "Hi!";
$body = "Hi,\n\nHow are you?";
$headers = "From: rchetan4141@gmail.com" . "\r\n";
if (mail($to, $subject, $body, $headers)) {
    echo ("Message successfully sent!");
} else {
    echo ("Message delivery failed...");
}

?>