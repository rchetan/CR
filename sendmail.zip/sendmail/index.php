<?php
$to = 'rchetan4141@gmail.com';
$subject = 'Test email'; 

$htmlContent = file_get_contents("email_template.html");
//$message = "Hello World!\n\nThis is my first mail."; 
$htmlContent = file_get_contents("email_template.html");
$headers = "From: chetan.zynqe@gmail.com\r\nReply-To: rchetan4141@gmail.com";
$mail_sent = @mail( $to, $subject, $htmlContent, $headers );
echo $mail_sent ? "Mail sent" : "Mail failed";
?>